package com.sussy.client;

public final class Module {
    private final String name;
    private final String description;
    private boolean enabled;

    public Module(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String name() { return name; }
    public String description() { return description; }
    public boolean enabled() { return enabled; }
    public void toggle() { enabled = !enabled; }
}
