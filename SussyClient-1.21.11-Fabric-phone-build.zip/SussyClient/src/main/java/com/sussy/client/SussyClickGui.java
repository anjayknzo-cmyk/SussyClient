package com.sussy.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public final class SussyClickGui extends Screen {
    private static final int BG = 0xF20B0D12;
    private static final int PANEL = 0xFF12151D;
    private static final int PANEL_2 = 0xFF191E29;
    private static final int ACCENT = 0xFF8B6CFF;
    private static final int MUTED = 0xFF8992A5;
    private static final int WHITE = 0xFFF2F3F8;

    private final String[] categories = {"Combat", "Render", "Movement", "World", "Misc"};
    private final List<Module> modules = new ArrayList<>();
    private int selectedCategory = 0;
    private int left, top, width = 430, height = 270;
    private boolean dragging;
    private double dragX, dragY;

    public SussyClickGui() {
        super(Text.literal("SUSSY CLIENT"));
        modules.add(new Module("Auto Totem", "Totem utility - configuration pending"));
        modules.add(new Module("Crystal Aura", "Combat module - configuration pending"));
        modules.add(new Module("Armor HUD", "Display equipped armor"));
        modules.add(new Module("Chunk Borders", "Display chunk boundaries"));
        modules.add(new Module("Coordinates", "Display current coordinates"));
        modules.add(new Module("Waypoints", "Manage saved locations"));
        modules.add(new Module("FPS Optimizer", "Lightweight client settings"));
        modules.add(new Module("Sus Chunk Finder", "Chunk analysis module - configuration pending"));
    }

    @Override
    protected void init() {
        left = (width - this.width) / 2;
        top = (height - this.height) / 2;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x66000000);
        ctx.fill(left, top, left + this.width, top + this.height, BG);
        ctx.fill(left, top, left + this.width, top + 3, ACCENT);
        ctx.fill(left, top + 3, left + 112, top + this.height, PANEL);
        ctx.fill(left + 112, top + 3, left + this.width, top + this.height, 0xEE0E1118);

        ctx.drawText(textRenderer, "SUSSY", left + 15, top + 16, WHITE, false);
        ctx.drawText(textRenderer, "CLIENT", left + 55, top + 16, ACCENT, false);
        ctx.drawText(textRenderer, "1.21.11  /  FABRIC", left + 15, top + 31, MUTED, false);
        ctx.fill(left + 12, top + 48, left + 100, top + 49, 0xFF2A3040);

        for (int i = 0; i < categories.length; i++) {
            int y = top + 60 + i * 29;
            boolean active = i == selectedCategory;
            if (active) {
                ctx.fill(left + 8, y - 5, left + 104, y + 19, 0xFF29233E);
                ctx.fill(left + 8, y - 5, left + 11, y + 19, ACCENT);
            }
            ctx.drawText(textRenderer, categories[i], left + 19, y + 2, active ? WHITE : MUTED, false);
        }

        ctx.drawText(textRenderer, categories[selectedCategory].toUpperCase(), left + 130, top + 17, WHITE, false);
        ctx.drawText(textRenderer, "MODULES  /  CLICK TO TOGGLE", left + 130, top + 33, MUTED, false);
        ctx.fill(left + 130, top + 48, left + this.width - 15, top + 49, 0xFF2A3040);

        int row = 0;
        for (Module module : visibleModules()) {
            int x = left + 130 + (row % 2) * 136;
            int y = top + 62 + (row / 2) * 47;
            int color = module.enabled() ? 0xFF28223D : PANEL_2;
            ctx.fill(x, y, x + 124, y + 37, color);
            ctx.drawText(textRenderer, module.name(), x + 9, y + 8, module.enabled() ? WHITE : 0xFFD0D4DF, false);
            ctx.fill(x + 9, y + 25, x + 115, y + 26, 0xFF303747);
            ctx.fill(x + 9, y + 25, x + (module.enabled() ? 42 : 18), y + 26, module.enabled() ? ACCENT : MUTED);
            row++;
        }

        ctx.drawText(textRenderer, "RSHIFT  •  CLOSE", left + 130, top + this.height - 20, MUTED, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private List<Module> visibleModules() {
        return switch (selectedCategory) {
            case 0 -> modules.subList(0, 2);
            case 1 -> modules.subList(2, 3);
            case 2 -> List.of();
            case 3 -> modules.subList(3, 6);
            default -> modules.subList(6, 8);
        };
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x();
        double mouseY = click.y();
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        if (mouseX >= left && mouseX <= left + this.width && mouseY >= top && mouseY <= top + 43) {
            dragging = true; dragX = mouseX - left; dragY = mouseY - top; return true;
        }
        for (int i = 0; i < categories.length; i++) {
            int y = top + 55 + i * 29;
            if (mouseX >= left + 8 && mouseX <= left + 104 && mouseY >= y && mouseY <= y + 24) {
                selectedCategory = i; return true;
            }
        }
        int row = 0;
        for (Module module : visibleModules()) {
            int x = left + 130 + (row % 2) * 136;
            int y = top + 62 + (row / 2) * 47;
            if (mouseX >= x && mouseX <= x + 124 && mouseY >= y && mouseY <= y + 37) {
                module.toggle(); return true;
            }
            row++;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double deltaX, double deltaY) {
        double mouseX = click.x();
        double mouseY = click.y();
        if (dragging && click.button() == 0) {
            left = (int) (mouseX - dragX);
            top = (int) (mouseY - dragY);
            return true;
        }
        return super.mouseDragged(click, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = false;
        return super.mouseReleased(click);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_RIGHT_SHIFT || input.key() == GLFW.GLFW_KEY_ESCAPE) {
            close(); return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean shouldPause() { return false; }
}
