# SUSSY CLIENT — Fabric 1.21.11

A lightweight client-side ClickGUI foundation. GUI opens with **Right Shift** and closes with Right Shift or Escape.

## Build

Requires Java 21 and Gradle 8.14+.

```bash
gradle build
```

Output: `build/libs/sussyclient-0.1.0.jar`

## Install

Install Fabric Loader for Minecraft 1.21.11 and matching Fabric API, then put the built JAR in `.minecraft/mods`.

## Current foundation

- Draggable dark ClickGUI inspired by compact PvP clients
- Category sidebar: Combat, Render, Movement, World, Misc
- Clickable module state toggles
- Right Shift open/close keybind
- Non-pausing screen

The module entries are UI scaffolding; feature logic and persistent config are the next implementation stage.
